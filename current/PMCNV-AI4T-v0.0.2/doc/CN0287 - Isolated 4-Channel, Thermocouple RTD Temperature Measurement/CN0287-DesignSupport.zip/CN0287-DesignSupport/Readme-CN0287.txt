Analog Devices Inc.
Design Support Package
CN-0287
08/18/2014
REV.B


This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.


**********************
*******Overview*******
**********************


CN-0287 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets and Evaluation Boards
	Schematics
	Bill of Materials	
	Gerber Layout Files
	PADs Layout Files
	Assembly Drawings		
	Link to Symbols and Footprints
	Link to Technical Support
	Link to Other Resources



**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for.  This file is provided as a PDF:
	CN0287: http://www.analog.com/CN0287


Product Datasheets and Evaluation Boards - Links to product pages for all ADI components used in the circuit.  These pages have links to PDFs of data sheets and evaluation board information:
	
	  AD7193:	http://www.analog.com/AD7193
	  AD8603:	http://www.analog.com/AD8603
	  AD5201:	http://www.analog.com/AD5201
	ADuM1280:	http://www.analog.com/ADuM1280
	ADuM5401:	http://www.analog.com/ADuM5401
	 ADT7310:	http://www.analog.com/ADT7310
	  ADG738:	http://www.analog.com/ADG738
	 ADR3440:	http://www.analog.com/ADR3440
	  ADG702:	http://www.analog.com/ADG702
	 ADP3336:	http://www.analog.com/ADP3336

Circuit Note Schematic: Provided as a .pdf file and a PADs .sch file:
	EVAL-CN0287-SDPZ-SCH-REVA.pdf
	EVAL-CN0287-SDPZ-SCH-REVA.sch


Bill of Material -  A complete list of components used within the circuit.  Details the quantity, value, and manufacturer information.  This file is provided in an Excel format:
	EVAL-CN0287-SDPZ-BOM-REVA.xls

PADs Layout Files and Assembly Drawings - Layout files provided in the .pcb and .pdf formats:
	EVAL-CN0287-SDPZ-PADS-REVA.pcb
	EVAL-CN0287-SDPZ-PADS-REVA.pdf


Gerber layout files - Layout files provided in Gerber and .pdf format within the .zip file:
	EVAL-CN0287-SDPZ-GRB-REVA.zip

Symbols and Footprints for ADI parts:

AD7193
http://www.analog.com/en/analog-to-digital-converters/ad-converters/ad7193/products/symbols-footprints.html
AD8603
http://www.analog.com/en/all-operational-amplifiers-op-amps/operational-amplifiers-op-amps/ad8603/products/symbols-footprints.html
AD5201
http://www.analog.com/en/digital-to-analog-converters/digital-potentiometers/ad5201/products/symbols-footprints.html
ADuM1280
http://www.analog.com/en/interface-isolation/digital-isolators/adum1280/products/symbols-footprints.html
ADuM5401
http://www.analog.com/en/interface-isolation/digital-isolators/adum5401/products/symbols-footprints.html
ADT7310
http://www.analog.com/en/analog-to-digital-converters/temperature-to-digital-converters/adt7310/products/symbols-footprints.html
ADG738
http://www.analog.com/en/switchesmultiplexers/multiplexers-muxes/adg738/products/symbols-footprints.html
ADR3440
http://www.analog.com/en/special-linear-functions/voltage-references/adr3440/products/symbols-footprints.html
ADG702
http://www.analog.com/en/switchesmultiplexers/multiplexers-muxes/adg702/products/symbols-footprints.html
ADP3336
http://www.analog.com/en/power-management/linear-regulators/adp3336/products/symbols-footprints.html


Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html

For Chinese Customer, Please contact us by technical hotline 4006-100-006 or Send email to china.support@analog.com.
More information in http://www.analog.com/zh.


**********************
***Other Resources****
**********************


Resources that are not provided by Analog Devices, but could be helpful.


Gerber Viewer:  http://www.graphicode.com


PADs Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/pads/pads-pcb-viewer


Allegro Physical Viewer: http://www.cadence.com/products/pcb/Pages/downloads.aspx


Freeware for EAGLE Light Edition:  http://www.cadsoft.de/freeware.htm

