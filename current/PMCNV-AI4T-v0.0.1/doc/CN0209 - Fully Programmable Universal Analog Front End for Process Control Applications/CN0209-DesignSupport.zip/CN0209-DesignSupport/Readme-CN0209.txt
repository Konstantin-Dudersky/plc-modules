Analog Devices Inc.
Design Support Package
CN-0209
09/18/2013
Rev. A


This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.


**********************
*******Overview*******
**********************


CN-0209 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets
	Link to Product Evaluation Boards and User Guides
	PADs Schematics
	Bill of Materials
	Assembly Drawings
	PADs Layout Files
	Gerber Layout Files	
	Link to Symbols and Footprints
	Link to Technical Support
	Link to Other Resources



**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for.  This file is provided as a PDF:

	CN0209: http://www.analog.com/CN0209


Product Datasheets - Links to all ADI component datasheets used in the circuit.  These files are provided as a PDF:

	AD7193:	http://www.analog.com/AD7193
	AD8275: http://www.analog.com/AD8275
	AD8676: http://www.analog.com/AD8676
	AD8617: http://www.analog.com/AD8617
	ADT7310: http://www.analog.com/ADT7310
	ADG1414: http://www.analog.com/ADG1414
	ADG442: http://www.analog.com/ADG442
	REF194: http://www.analog.com/REF194
	ADP1720: http://www.analog.com/ADP1720
	ADuM1400: http://www.analog.com/ADUM1400
	ADuM1401:http://www.analog.com/ADUM1401

	
AD7193 Evaluation Boards and Kits:
	 
	http://www.analog.com/en/analog-to-digital-converters/ad-converters/ad7193/products/evaluation-boards-kits/index.html

System Demonstration Platform:
http://www.analog.com/en/embedded-processing-dsp/blackfin/bf527sdp-hw/processors/product.html

SDP Board User Guide:
http://www.analog.com/static/imported-files/user_guides/SDP_UG_rev1.2.pdf


Schematic for EVAL-CN0209-SDPZ:

	EVAL-CN0209-SDPZ-SCH-RevB.sch
	EVAL-CN0209-SDPZ-SCH-RevB.pdf
	

Bill of Materials for EVAL-CN0209-SDPZ:

	
	EVAL-CN0209-SDPZ-BOM-RevB.xls


Layout Drawings (PADS) for EVAL-CN0209-SDPZ:

	EVAL-CN0209-SDPZ-PADS-RevB.pcb
	
	
Gerber Layout Files:

	EVAL-CN0209-SDPZ-GRB-RevB.zip

CN0209 Software Readme File:

	CN0209-Software-Readme.pdf

		
Symbols and Footprints:

AD7193:	
http://www.analog.com/en/analog-to-digital-converters/ad-converters/ad7193/products/symbols-footprints.html

AD8275: 
http://www.analog.com/en/amplifiers-and-comparators/current-sense-amplifiers/ad8275/products/symbols-footprints.html

AD8676: 
http://www.analog.com/en/amplifiers-and-comparators/operational-amplifiers-op-amps/ad8676/products/product.html

AD8617: 
http://www.analog.com/en/amplifiers-and-comparators/operational-amplifiers-op-amps/ad8617/products/symbols-footprints.html

ADT7310: 
http://www.analog.com/en/analog-to-digital-converters/temperature-to-digital-converters/adt7310/products/symbols-footprints.html

ADG1414: 
http://www.analog.com/en/switchesmultiplexers/analog-switches/adg1414/products/symbols-footprints.html

ADG442: 
http://www.analog.com/en/switchesmultiplexers/analog-switches/adg442/products/symbols-footprints.html

REF194: 
http://www.analog.com/en/references/voltage-references/ref194/products/symbols-footprints.html

ADP1720: 
http://www.analog.com/en/power-management/linear-regulators/adp1720/products/symbols-footprints.html

ADuM1400: 
http://www.analog.com/en/interface/digital-isolators/adum1400/products/symbols-footprints.html

ADuM1401:
http://www.analog.com/en/interface/digital-isolators/adum1401/products/symbols-footprints.html


Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html



**********************
***Other Resources****
**********************


Resources that are not provided by Analog Devices, but could be helpful.


Gerber Viewer:  http://www.graphicode.com

PADs Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/pads/pads-pcb-viewer

Allegro Physical Viewer: http://www.cadence.com/products/pcb/Pages/downloads.aspx


